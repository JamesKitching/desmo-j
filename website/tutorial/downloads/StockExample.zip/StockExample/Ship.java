package desmoj.tutorial2.StockExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a ship in the StockExample model.
 * 
 * A ship arrives a the container terminal and delivers a number of containers
 * to each of the four different storage areas (stocks). After that, it leaves the
 * system.
 * 
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class Ship extends SimProcess {

    /**
     * no of containers destined for Eastern Europe
     */
    private long numEast = 0;

    /**
     * no of containers destined for Northern Europe
     */
    private long numNorth = 0;

    /**
     * no of containers destined for Central Europe
     */
    private long numCentral = 0;

    /**
     * no of containers destined for Germany
     */
    private long numGermany = 0;

    /**
     * Constructs a new ship.
     * 
     * @param model
     *            the model this process belongs to
     * @param name
     *            this ship's name
     * @param showInTrace
     *            flag to indicate if this process shall produce output for the
     *            trace
     */
    public Ship(StockExample model, String name, boolean showInTrace) {
        super(model, name, showInTrace);

        // determine number of containers for each destination
        numEast = model.getNumberOfContainers();
        numNorth = model.getNumberOfContainers();
        numCentral = model.getNumberOfContainers();
        numGermany = model.getNumberOfContainers();
    }

    /**
     * Describes this ship's life cycle:
     * 
     * On arrival, the ship will deliver a number of containers to each of the
     * four storage areas. The duration of the unloading is not modelled. After
     * unloading it leaves the system.
     */
    public void lifeCycle() throws SuspendExecution {
        
        StockExample model = (StockExample)this.getModel();

        // Ship arrives and delivers containers to each stock
        model.east.store(numEast);
        sendTraceNote("number of containers/east: " + model.east.getAvail());
        model.north.store(numNorth);
        sendTraceNote("number of containers/north: " + model.north.getAvail());
        model.central.store(numCentral);
        sendTraceNote("number of containers/central: " + model.central.getAvail());
        model.germany.store(numGermany);
        sendTraceNote("number of containers/Germany: " + model.germany.getAvail());

        // send a message into the trace after service
        sendTraceNote("leaves the port");
    }
}