package desmoj.tutorial2.StockExample;

import desmoj.core.simulator.*;
import desmoj.core.advancedModellingFeatures.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a train in the StockExample model.
 * 
 * Each train has one of four destinations (Northern, Central, Eastern Europe or
 * Germany and has a certain length, i.e. it can carry a certain number of
 * containers. On arrival at the the railway station of the container terminal
 * the train requests the number of containers from the storage area (Stock) of
 * its destination. This may result in the train having to wait until enough
 * containers are available. When the train is loaded, it leaves the system.
 * 
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class Train extends SimProcess {

    /** the storage area for the train's destination */
    Stock storage;

    /** the train's length (in number of containers) */
    long length;

    public Train(StockExample model, String name, boolean showInTrace, Stock storage) {
        super(model, name, showInTrace);

        // store a reference to the storage area
        this.storage = storage;
        // determine length of train
        length = model.getTrainLength();

    }

    /**
     * Describes this train's lifecycle:
     * 
     * On arrival at the the railway station of the container terminal the train
     * requests the number of containers from the storage area (Stock) of its
     * destination. This may result in the train having to wait until enough
     * containers are available. When the train is loaded, it leaves the system,
     * freeing the track for the next train.
     */
    public void lifeCycle() throws SuspendExecution {

        // send some information to the tracefile for documentation reasons
        sendTraceNote("Train length:  " + length + " containers");

        // load containers from storage
        // --> the process may be passivated and placed on an internal queue
        // by the stock if there are not enough containers available
        storage.retrieve(this.length);
        // train is loaded and can leave the system

        // create successor train (starts in half an hour)
        new Train((StockExample) getModel(), "Train to " + storage.getName(), true, storage)
                .activate(new TimeSpan(0.5));

    }
}