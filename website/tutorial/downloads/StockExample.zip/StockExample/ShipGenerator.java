package desmoj.tutorial2.StockExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a process source, which continually generates ships in
 * order to keep the simulation running.
 * 
 * It will create a new ship, activate it (so that it arrives at the quai) and
 * then wait until the next ship arrival is due.
 * 
 * @author Ruth Meyer
 */
public class ShipGenerator extends SimProcess {

    /**
     * Constructs a new ship generator process.
     * 
     * @param owner
     *            the model this ship generator belongs to
     * @param name
     *            this ship generator's name
     * @param showInTrace
     *            flag to indicate if this process shall produce output for the
     *            trace
     */
    public ShipGenerator(Model owner, String name, boolean showInTrace) {
        super(owner, name, showInTrace);
    }

    /**
     * describes this process's life cycle: continually generate new ships.
     */
    public void lifeCycle() throws SuspendExecution {

        // get a reference to the model
        StockExample model = (StockExample) getModel();

        // endless loop:
        while (true) {

            // create a new ship activate it
            new Ship(model, "Ship", true).activate();

            // wait until next ship arrival is due
            hold(new TimeSpan(model.getShipArrivalTime()));
        }
    }
} /* end of process class */
