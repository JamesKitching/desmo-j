package desmoj.tutorial2.InterruptsExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a van carrier in the InterruptsExample model. The VC
 * waits until a truck requests its service. It will then fetch the container
 * and load it onto the truck. If there is another truck waiting it starts
 * serving this truck. Otherwise it waits again for the next truck to arrive.
 * Serving a truck may be interrupted by the arrival of an urgent truck. A VC
 * will then stop serving the "normal" truck, put it back into the queue of
 * waiting trucks and start service on the urgent truck.
 * 
 * @author Olaf Neidhardt, Ruth Meyer
 */

public class VanCarrier extends SimProcess {

    /**
     * Constructor of the van carrier process
     * 
     * @param model
     *            the model this process belongs to
     * @param name
     *            this VC's name
     * @param showInTrace
     *            flag to indicate if this process shall produce output for the
     *            trace
     */
    public VanCarrier(InterruptsExample model, String name, boolean showInTrace) {
        super(model, name, showInTrace);
    }

    /**
     * Describes this van carrier's life cycle.
     * 
     * It will continually loop through the following steps: Check if there is a
     * customer waiting. If there is someone waiting a) remove customer from
     * queue b) serve customer c) check if there was an interrupt; if yes, stop
     * serving the current truck and put it back into the queue of waiting
     * trucks d) return to top If there is no one waiting a) wait (passivate)
     * until someone arrives (who reactivates the VC) b) return to top
     */
    public void lifeCycle() throws SuspendExecution {
        
        InterruptsExample model = (InterruptsExample) this.getModel();

        // the van carrier is always on duty and will never stop working
        while (true) {
            // check if there is someone waiting
            if (model.truckQueue.isEmpty()) {
                // NO, there is no one waiting

                // insert self into the idle VC queue
                model.idleVCQueue.insert(this);
                // and wait for things to happen
                passivate();
            } else {
                // YES, here is a customer (truck) waiting

                // get a reference to the first truck from the truck queue
                // (urgent trucks are placed in the front of the queue due to
                // their higher priority)
                Truck nextTruck = model.truckQueue.first();
                // remove the truck from the queue
                model.truckQueue.remove(nextTruck);

                // insert self into busy VC queue
                model.busyVCQueue.insert(this);

                // fetch container and load it onto truck
                // service time is represented by a hold of the VC process
                hold(new TimeSpan(model.getServiceTime()));

                // check if an urgent truck interrupted the service
                if (isInterrupted()) {
                    // yes, there has been an interrupt
                    // --> handle the interrupt
                    sendTraceNote("interrupted!");
                    // raise priority of the interrupted truck
                    nextTruck.setQueueingPriority(Truck.HIGH);
                    // insert it back into the queue of waiting trucks
                    // --> due to higher priority it will be inserted before any
                    // "normal" trucks so that it will be served prior to them
                    model.truckQueue.insert(nextTruck);

                    // clear interrupt code
                    this.clearInterruptCode();
                } else {
                    // no, there has been no interrupt
                    // --> the service is completed and the truck may leave
                    nextTruck.activate();
                }
            }
        }
    }
} /* end of process class */
