package desmoj.tutorial2.InterruptsExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a process source, which continually generates trucks in
 * order to keep the simulation running.
 * 
 * It will create a new truck, activate it (so that it arrives at the terminal)
 * and then wait until the next truck arrival is due.
 * 
 * @author Ruth Meyer
 */
public class TruckGenerator extends SimProcess {

    /**
     * TruckGenerator constructor.
     * 
     * @param owner
     *            the model this truck generator belongs to
     * @param name
     *            this truck generator's name
     * @param showInTrace
     *            flag to indicate if this process shall produce output for the
     *            trace
     */
    public TruckGenerator(Model owner, String name, boolean showInTrace) {
        super(owner, name, showInTrace);
    }

    /**
     * Describes this process's life cycle: continually generate new trucks.
     */
    public void lifeCycle() throws SuspendExecution {

        // get a reference to the model
        InterruptsExample model = (InterruptsExample) getModel();

        // endless loop:
        while (true) {

            // create a new truck
            Truck truck = new Truck(model, "Truck", true);
            // and let is arrive at the terminal
            truck.activate();

            // wait until next truck arrival is due
            hold(new TimeSpan(model.getTruckArrivalTime()));
        }
    }
} /* end of process class */
