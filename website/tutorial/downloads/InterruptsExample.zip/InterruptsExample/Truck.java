package desmoj.tutorial2.InterruptsExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents the truck in the InterruptsExample model.
 * 
 * A truck arrives at the container terminal and requests loading of a
 * container. If possible, it is served by the van carrier immediately.
 * Otherwise it waits in the parking area for its turn. After service is
 * completed, it leaves the system.
 * 
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class Truck extends SimProcess {

    /** A code for high priority (= urgent) trucks) */
    public static final int HIGH = 2;

    /** A code for low priority (= not urgent) trucks) */
    public static final int LOW = 0;

    /**
     * Constructor of the truck process
     * 
     * @param model
     *            the model this process belongs to
     * @param name
     *            this truck's name
     * @param showInTrace
     *            flag to indicate if this process shall produce output for the
     *            trace
     */
    public Truck(InterruptsExample model, String name, boolean showInTrace) {

        super(model, name, showInTrace);
        // determine if this truck is urgent
        if (model.getTruckIsUrgent()) {
            this.setQueueingPriority(HIGH);
        } else {
            this.setQueueingPriority(LOW);
        }
    }

    /**
     * Describes this truck's life cycle:
     * 
     * On arrival, the truck will enter queue (parking lot). It will then check
     * if the van carrier is available. If this is the case, it will activate
     * the van carrier to get serviced and transfer the control to the VC.
     * Otherwise it just passivates (waits) or -- if it is an urgent truck --
     * interrupts a busy van carrier. After service it leaves the system.
     */
    public void lifeCycle() throws SuspendExecution {

        InterruptsExample model = (InterruptsExample) this.getModel();

        // enter parking-lot
        model.truckQueue.insert(this);
        sendTraceNote("TruckQueuelength: " + model.truckQueue.length());

        // check if a VC is available
        if (!model.idleVCQueue.isEmpty()) {
            // yes, it is

            // get a reference to the first VC from the idle VC queue
            VanCarrier vanCarrier = model.idleVCQueue.first();
            // remove the van carrier from the queue
            model.idleVCQueue.remove(vanCarrier);
            // place the VC on the eventlist right after me,
            // to ensure that I will be the next customer to get serviced
            vanCarrier.activateAfter(this);
        }
        // if not, check if this is an urgent truck
        else if (this.getQueueingPriority() == HIGH) {
            // yes, this truck is urgent --> interrupt the first busy VC

            // get a reference to the first VC from the busy VC queue
            VanCarrier vanCarrier = model.busyVCQueue.first();
            // remove the van carrier from the queue
            model.busyVCQueue.remove(vanCarrier);
            // interrupt it
            vanCarrier.interrupt(model.urgentTruckArrived);
        }

        // wait for service
        passivate();

        // service completed --> leave the system
        sendTraceNote("Truck was serviced and leaves system.");
    }
} /* end of process class */
