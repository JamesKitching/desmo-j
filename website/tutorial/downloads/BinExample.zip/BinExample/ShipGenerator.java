package desmoj.tutorial2.BinExample;

import desmoj.core.simulator.*;
import java.util.concurrent.TimeUnit;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a process source, which continually generates
 * ships in order to keep the simulation running.
 *
 * It will create a new ship, activate it (so that it arrives at
 * the quai) and then wait until the next ship arrival is
 * due.
 * @author Ruth Meyer
 */
public class ShipGenerator extends SimProcess {

	/**
	 * Constructs a new ship generator process.
	 * @param owner the model this ship generator belongs to
	 * @param name this ship generator's name
	 * @param showInTrace flag to indicate if this process shall produce output for the trace
	 */
	public ShipGenerator(Model owner, String name, boolean showInTrace) {
		super(owner, name, showInTrace);
	}
	/**
	 * describes this process's life cycle: continually generate new ships.
	 */
	public void lifeCycle() throws SuspendExecution {

		// get a reference to the model
		BinExample model = (BinExample)getModel();

		// endless loop:
		while (true) {

			// create a new ship
			Ship newShip = new Ship(model, "Ship", true);
			// and let it arrive at the harbour (i.e. activate it)
			newShip.activate();

			//wait until next ship arrival is due
			hold(new TimeSpan(model.getShipArrivalTime(), TimeUnit.MINUTES));
		}
	}
} /* end of process class */
