package desmoj.tutorial2.BinExample;

import desmoj.core.simulator.*;
import desmoj.core.dist.*;
import desmoj.core.advancedModellingFeatures.*;
import java.util.concurrent.TimeUnit;

/**
 * This is the model class. It is the main class of a simple process-oriented
 * model of the railway station inside a container terminal using bins to represent
 * different storage areas.
 * Container ships arrive at the terminal and deliver containers to the storage
 * areas. From there they are loaded onto trains that leave for four different
 * destinations: Northern, Central, and Eastern Europe and Germany. Each
 * destination is allocated a storage area (Bin). Trains only load containers
 * from the storage area that is associated with their destination whereas
 * ships deliver containers to all storage areas.
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class BinExample extends Model {

	/**	A random stream to determine the number of containers for each destination */
	private DiscreteDistUniform containerDestinationStream;

	/**	A random stream to determine the time of arrival of the next ship */
	private ContDistExponential shipArrivalStream;

	/** A random stream to determine the length of a train */
	private DiscreteDistUniform trainLengthStream;

	/** A Bin construct used to used to keep the Eastern Europe bound containers */
	protected Bin east;

	/** A Bin construct used to used to keep the Northern Europe bound containers */
	protected Bin north;

	/** A Bin construct used to used to keep the Central Europe bound containers */
	protected Bin central;

	/** A Bin construct used to used to keep the Germany bound containers */
	protected Bin germany;

	/**
	 * This method constructs a new instance of a BinExample Model
	 * Needed parameters are
	 * @param owner Model    the owning model, normally "null"
	 * @param name String   a name representing the model
	 * @param showInReport boolean    shall the model be represented in model report?
	 * @param showIntrace boolean     and in trace?
	 */
	public BinExample(Model owner, String name, boolean showInReport, boolean showIntrace) {

		// call the constructor of the superclass
		super(owner, name, showInReport, showIntrace);

	}
	/** returns a description of the model */
	public String description() {
		return "This is a simple process-oriented model of the railway station "+
		"inside a container terminal using bins to represent different storage areas. " +
		"Container ships arrive at the terminal and deliver containers to the storage " +
		"areas. From there they are loaded onto trains that leave for four different " +
		"destinations: Northern, Central, and Eastern Europe and Germany. Each " +
		"destination is allocated a storage area (Bin). Trains only load containers " +
		"from the storage area that is associated with their destination whereas " +
		"ships deliver containers to all storage areas.";
	}
	/**
	 * activates dynamic model components (simulation processes).
	 *
	 * This method is used to place all events or processes on the
	 * internal event list of the simulator which are necessary to start
	 * the simulation.
	 *
	 * In this case, the ship generator and the first four trains (one for each
	 * (destination) have to be created and activated.
	 */
	public void doInitialSchedules() {

		// create and activate the ship generator
		ShipGenerator generator = new ShipGenerator(this, "ShipGenerator", true);
		generator.activate(new TimeSpan(getShipArrivalTime(), TimeUnit.MINUTES));

		// create one train per direction
		// ...and activate it too to ensure transportation
		Train easternBound = new Train(this, "Train to "+east.getName(), true, east);
		easternBound.activate();

		Train northernBound = new Train(this, "Train to "+north.getName(), true, north);
		northernBound.activate();

		Train centralBound = new Train(this, "Train to "+central.getName(), true, central);
		centralBound.activate();

		Train germanyBound = new Train(this, "Train to "+germany.getName(), true, germany);
		germanyBound.activate();

	}
	/**
	 * This method is used by the model components to receive
	 * a new sample out of a random stream.
	 * In this case it delivers a number of container containers.
	 * @return int
	 */
	protected long getNumberOfContainers() {
	    
		return containerDestinationStream.sample();
	}
	
	/**
	 * This method is used by the model components to receive
	 * a new sample out of a random stream.
	 * In this case it delivers a new inter-arrival time for the
	 * arrival of the next ship.
	 * @return double
	 */
	protected double getShipArrivalTime() {
	    
		return shipArrivalStream.sample();
	}
	
	/**
	 * This method is used by the model components to receive
	 * a new sample out of a random stream.
	 * In this case it delivers a train length (= number of container wagons)
	 * @return int
	 */
	protected long getTrainLength() {
	    
		return trainLengthStream.sample();
	}
	
	/**
	 * initialises static model components like distributions and queues.
	 */
	public void init() {
	    
		// initialise distributions
		// (1) for the number of containers a ship delivers to a destination
		containerDestinationStream = new DiscreteDistUniform(this,"No of containers per destination", 25,400, true, false);
		// (2) for the ships' interarrival time
		shipArrivalStream = new ContDistExponential(this,"Ships Arrival Stream", 6.0, true, false); ;
		// (3) for the length of trains (= number of containers they transport)
		trainLengthStream = new DiscreteDistUniform(this, "Train Length Stream", 30,90, true, false);

		// initialise the bins (storage areas), each with an initial number of 50 containers already stored in them
		east = new desmoj.core.advancedModellingFeatures.Bin(this, "Eastern Europe",50, true, true);
		north = new desmoj.core.advancedModellingFeatures.Bin(this, "Northern Europe",50, true, true);
		central = new desmoj.core.advancedModellingFeatures.Bin(this, "Central Europe",50, true, true);
		germany = new desmoj.core.advancedModellingFeatures.Bin(this, "Germany",50, true, true);
	}
	   
    /** run the model */  
	public static void main(java.lang.String[] args) {

		// create model and experiment
		BinExample model = new BinExample(null, "BinExample", true, false);
		Experiment exp = new Experiment("BinExampleExperiment", TimeUnit.SECONDS, TimeUnit.MINUTES, null);

		// connect both
		model.connectToExperiment(exp);

		// set experiment parameters
		exp.setShowProgressBar(true);  // display a progress bar (or not)
		exp.stop(new TimeInstant(1500, TimeUnit.MINUTES));   // set end of simulation at 500 minutes
		exp.tracePeriod(new TimeInstant(0), new TimeInstant(100, TimeUnit.MINUTES));  // set the period of the trace
		exp.debugPeriod(new TimeInstant(0), new TimeInstant(50, TimeUnit.MINUTES));   // and debug output

		// start the Experiment with start time 0.0
		exp.start();

		// --> now the simulation is running until it reaches its ending criterion
		// ...
		// ...
		// <-- after reaching the ending criterion, the main thread returns here

		// generate the report (and other output files)
		exp.report();

		// stop all threads still alive and close all output files
		exp.finish();
	}
}