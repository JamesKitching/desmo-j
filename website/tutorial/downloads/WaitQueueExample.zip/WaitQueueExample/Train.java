package desmoj.tutorial2.WaitQueueExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class models a train delivering coal to the seaport.
 * 
 * @author Ruth Meyer
 */
public class Train extends SimProcess {

    /** standard constructor */
    public Train(WaitQueueExample model) {
        super(model, "Train", true);
    }

    /** this train's life cycle */
    public void lifeCycle() throws SuspendExecution {

        // get a reference to the model
        WaitQueueExample model = (WaitQueueExample) getModel();

        // create and schedule successor
        new Train(model).activate(new TimeSpan(model.trainArrivals.sample()));

        // request to be unloaded
        model.transferPoint.waitOnCoop();
    }
} /* end of class Train */
