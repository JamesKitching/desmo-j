package desmoj.tutorial2.WaitQueueExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class models a ship.
 * 
 * @author Ruth Meyer
 */
public class Ship extends SimProcess {

    /** standard constructor */
    public Ship(WaitQueueExample model) {
        super(model, "Ship", true);
    }

    /** this ship's lifecycle */
    public void lifeCycle() throws SuspendExecution {

        // get a reference to the model
        WaitQueueExample model = (WaitQueueExample) getModel();

        // create and schedule successor
        new Ship(model).activate(new TimeSpan(model.shipArrivals.sample()));

        // request two train loads of coal --> may cause delay
        for (int i = 0; i < 2; i++) {
            model.transferPoint.cooperate(model.coalTransfer);
        }
    }
} /* end of class Ship */
