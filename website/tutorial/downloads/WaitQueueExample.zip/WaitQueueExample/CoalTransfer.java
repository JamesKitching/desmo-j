package desmoj.tutorial2.WaitQueueExample;

import desmoj.core.simulator.*;
import desmoj.core.advancedModellingFeatures.ProcessCoop;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * The process cooperation between train and ship: transfers coal from train
 * onto ship.
 * 
 * @author Ruth Meyer
 */
public class CoalTransfer extends ProcessCoop<Ship, Train> {

    /** standard constructor */
    public CoalTransfer(WaitQueueExample model) {
        super(model, "coal transfer", true);
    }

    /**
     * performs the cooperation between master (ship) and slave (train); i.e.
     * unloads the train and loads the ship.
     */
    public void cooperation(Ship master, Train slave) {
        // just hold for the length of time it takes to transfer the coal
        hold(new TimeSpan(((WaitQueueExample) getModel()).unload.sample()));
    }
}
