package desmoj.tutorial2.WaitQueueExample;

import desmoj.core.simulator.*;
import desmoj.core.dist.*;
import desmoj.core.advancedModellingFeatures.*;
import java.util.concurrent.TimeUnit;

/**
 * This is the model class. It describes a seaport loading coal from trains onto
 * ships using direct process synchronisation via the WaitQueue construct. Each
 * ship can carry the load of two trains and will not leave until fully loaded.
 * 
 * @author Ruth Meyer
 */
public class WaitQueueExample extends Model {

    /** distribution for train arrival */
    protected ContDistExponential trainArrivals;

    /** distribution for ship arrival */
    protected ContDistExponential shipArrivals;

    /** distribution for unloading a train/loading a ship */
    protected ContDistUniform unload;

    /** wait queue used to synchronise trains and ships */
    protected WaitQueue<Ship, Train> transferPoint;

    /** the transfer of coal from train to ship (a process cooperation) */
    protected CoalTransfer coalTransfer;

    /** standard constructor */
    public WaitQueueExample(Model owner, String name, boolean showInReport, boolean showIntrace) {

        super(owner, name, showInReport, showIntrace);
    }

    /** returns this model's description */
    public String description() {

        return "A simple process-oriented model to demonstrate the use of the WaitQueue construct."
                + "It describes a busy seaport loading coal from trains onto ships using direct "
                + "process synchronisation. Each ship can carry the load of two trains and will "
                + "not leave until full.";
    }

    /** initialises static model components */
    public void init() {

        // initialise distributions
        trainArrivals = new ContDistExponential(this, "Train Arrival", 30.0, true, false);
        shipArrivals = new ContDistExponential(this, "Ship Arrival", 60.0, true, false);
        unload = new ContDistUniform(this, "Train Unload", 60.0, 180.0, true, false);

        // initialise waitQueue and process cooperation
        transferPoint = new WaitQueue<Ship, Train>(this, "Coal Transfer", true, true);
        coalTransfer = new CoalTransfer(this);
    }

    /** create and activate a train and a ship */
    public void doInitialSchedules() {

        // each train and ship create their successor, respectively
        // --> only the first of each type of process needs to be scheduled here
        new Train(this).activate();
        new Ship(this).activate();
    }

    /** runs the model */
    public static void main(String[] args) {

        // create model and experiment
        WaitQueueExample model = new WaitQueueExample(null, "WaitQueueExample", true, false);
        Experiment exp = new Experiment("WaitQueueExampleExperiment", TimeUnit.SECONDS,
                TimeUnit.MINUTES, null);

        // connect both
        model.connectToExperiment(exp);

        // set experiment parameters
        exp.setShowProgressBar(true); // display a progress bar (or not)
        exp.stop(new TimeInstant(12000)); // set end of simulation at 500
                                          // minutes
        exp.tracePeriod(new TimeInstant(0), new TimeInstant(500)); // set the
                                                                   // period of
                                                                   // the trace
        exp.debugPeriod(new TimeInstant(0), new TimeInstant(50)); // and debug
                                                                  // output

        // start the Experiment with start time 0.0
        exp.start();

        // --> now the simulation is running until it reaches its ending
        // criterion
        // ...
        // ...
        // <-- after reaching the ending criterion, the main thread returns here

        // generate the report (and other output files)
        exp.report();

        // stop all threads still alive and close all output files
        exp.finish();
    }

} /* end of class WaitQueueExample */