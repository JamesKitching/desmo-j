package desmoj.tutorial2.CountExample;
import desmoj.core.simulator.*;
import desmoj.core.advancedModellingFeatures.Bin;
import java.util.concurrent.TimeUnit;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a train in the CountExample
 * model.
 *
 * Each train has one of four destinations (Northern, Central, Eastern Europe
 * or Germany and has a certain length, i.e. it can carry a certain number of
 * containers. On arrival at the the railway station of the container terminal
 * the train requests the number of containers from the storage area (Bin) of
 * its destination. This may result in the train having to wait until enough
 * containers are available.
 * When the train is loaded, it updates the counters and leaves the system.
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class Train extends SimProcess {

	/**
	 * Keeps a reference to the model this model component is a part of
	 * useful shortcut to access the model infrastructure
	 */
	CountExample myModel;

	/** the storage area for the train's destination */
	Bin storage;

	/** the train's length (in number of containers) */
	long length;

	/**
    * Constructs a new ship.
	 * @param owner the model this process belongs to
	 * @param name this ship's name
	 * @param showInTrace flag to indicate if this process shall produce output for the trace
	*/
	public Train(Model owner, String name, boolean showInTrace, Bin storage) {
		super(owner, name, showInTrace);

		// store a reference to the model to avoid type casts
		myModel = (CountExample) owner;
		// store a reference to the storage area
		this.storage = storage;
		// determine length of train
		length = myModel.getTrainLength();

	}
	/**
	 * Describes this train's lifecycle:
	 *
	 *	On arrival at the the railway station of the container terminal
	 * the train requests the number of containers from the storage area (Bin) of
	 * its destination. This may result in the train having to wait until enough
	 * containers are available.
	 * When the train is loaded, it leaves the system, freeing the track
	 * for the next train.
	 */
	public void lifeCycle() throws SuspendExecution {

		// send some information to the tracefile for documentation reasons
		sendTraceNote("Train length:  " + length + " containers");

		// load containers from storage
		// --> the process may be passivated and placed on an internal queue
		// by the bin if there are not enough containers available
		storage.retrieve(this.length);

		// train is loaded and can leave the system: update statistics (counters)
		myModel.numberOfTrains.update();
		myModel.numberOfContainers.update(length);

		// create successor train and schedule it for arrival in half a minute
		Train nextTrain = new Train(myModel, "Train to "+storage.getName(), true, storage);
		nextTrain.activate(new TimeSpan(0.5, TimeUnit.MINUTES));
	}
}