package desmoj.tutorial2.CountExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a ship in the CountExample
 * model.
 *
 * A ship arrives a the container terminal and delivers a number of containers
 * to each of the four different storage areas (bins).
 * After that, it leaves the system.
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class Ship extends SimProcess {

	/**
	 * Keeps a reference to the model this model component is a part of
	 * useful shortcut to access the model infrastructure
	 */
	private CountExample myModel = null;

	/**
	 * no of containers destined for Eastern Europe
	 */
	private long numEast = 0;
	/**
	 * no of containers destined for Northern Europe
	 */
	private long numNorth = 0;
	/**
	 * no of containers destined for Central Europe
	 */
	private long numCentral = 0;
	/**
	 * no of containers destined for Germany
	 */
	private long numGermany = 0;
	/**
	 * Constructs a new ship.
	 * @param owner the model this process belongs to
	 * @param name this ship's name
	 * @param showInTrace flag to indicate if this process shall produce output for the trace
	*/
	public Ship(Model owner, String name, boolean showInTrace) {
		super(owner, name, showInTrace);

		// store a reference to the model to avoid type casts
		myModel = (CountExample) owner;
		// determine number of containers for each destination
		numEast = myModel.getNumberOfContainers();
		numNorth = myModel.getNumberOfContainers();
		numCentral = myModel.getNumberOfContainers();
		numGermany = myModel.getNumberOfContainers();
	}
	/**
	 * Describes this ship's life cycle:
	 *
	 * On arrival, the ship will deliver a number of containers to each of
	 * the four storage areas. The duration of the unloading is not modelled.
	 * After unloading it leaves the system.
	 */
	public void lifeCycle() throws SuspendExecution {

		//Ship arrives and delivers containers to each bin
		//east
		myModel.east.store(numEast);
		sendTraceNote("number of containers in east: " + myModel.east.getAvail());

		//north
		myModel.north.store(numNorth);
		sendTraceNote("number of containers in north: " + myModel.north.getAvail());

		//central
		myModel.central.store(numCentral);
		sendTraceNote("number of containers in central: " + myModel.central.getAvail());

		//Germany
		myModel.germany.store(numGermany);
		sendTraceNote("number of containers in german: " + myModel.germany.getAvail());

		//send a message into the trace after service
		sendTraceNote("leaves the port");

		//ship finished and dismissed...
	}
}