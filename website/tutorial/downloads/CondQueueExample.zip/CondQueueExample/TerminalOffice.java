package desmoj.tutorial2.CondQueueExample;

import desmoj.core.simulator.*;
import java.util.concurrent.TimeUnit;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents the terminal office in the CondQueueExample model.
 * The terminal office announces every day at 7 o'clok which ships are
 * bound to arrive within the next 48 hours. Technically speaking, the
 * terminal office is a process source which continually creates new
 * ships and schedules them for activation at their arrival time to
 * keep the simulation running.
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class TerminalOffice extends SimProcess {

    /**
     * Constructs a new terminal office (i.e. ship generator process).
     * @param owner the model this terminal office belongs to
     * @param name this terminal office's name
     * @param showInTrace flag to indicate if this process shall produce output for the trace
     */
    public TerminalOffice(Model owner, String name, boolean showInTrace) {
        super(owner, name, showInTrace);
    }

    /**
     * describes this process's life cycle: publishes every day at 7 o'clock
     * which ships will arrive during the next 48 hours (i.e. it creates
     * and activates the respective new ship processes).
     */
    public void lifeCycle() throws SuspendExecution {

        // get a reference to the model
        CondQueueExample model = (CondQueueExample)getModel();

        // endless loop:
        while(true){

            // determine number of incoming ships
            int incomingShips = (int) model.getNumOfShipArrivals();
            sendTraceNote("Ships to be activated : " + incomingShips);

            // create and schedule these ships for their time of arrival
            for (int i = 1; i <= incomingShips; i++) {
                Ship ship = new Ship(model, "Ship", true);
                ship.activate(new TimeSpan(model.getShipArrivalTime()));
                // insert ship into list of incoming ships
                model.incomingShips.add(ship);
            }

            sendTraceNote("New total of incoming ships : " + model.incomingShips.size());

            // wait for 24 hours, i.e. until the next day at 7 o'clock
            hold(new TimeSpan(1440));
        }
    }
}
