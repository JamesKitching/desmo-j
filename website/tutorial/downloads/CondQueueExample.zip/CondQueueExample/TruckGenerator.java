package desmoj.tutorial2.CondQueueExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a process source, which continually generates
 * trucks in order to keep the simulation running.
 * It will create a new truck, activate it (so that it arrives at
 * the terminal) and then wait until the next truck arrival is
 * due.
 * @author Ruth Meyer
 */
public class TruckGenerator extends SimProcess {

    /**
     * Constructs a new truck generator process.
     * @param owner the model this ship generator belongs to
     * @param name this ship generator's name
     * @param showInTrace flag to indicate if this process shall produce output for the trace
     */
    public TruckGenerator(Model owner, String name, boolean showInTrace) {
        super(owner, name, showInTrace);
    }

    /**
     * describes this process's life cycle: continually generate new trucks when
     * there are ships awaited to arrive at the harbour.
     */
    public void lifeCycle() throws SuspendExecution {

        // get a reference to the model
        CondQueueExample model = (CondQueueExample)getModel();

        // endless loop:
        while (true) {

            // check if there are incoming ships
            if (model.incomingShips.size() > 0) {
                // yes, there are
                // create a new truck
                Truck newTruck = new Truck(model, "Truck", true);
                // and let it arrive at the harbour (i.e. activate it)
                newTruck.activate();
                // wait until next truck arrival is due
                hold(new TimeSpan(model.getTruckArrivalTime()));
            }
            else {
                // no, there aren't any
                // wait until terminal office announces new ships
                activateAfter(model.terminalOffice);
                passivate();
            }
        }
    }
} /* end of process class */
