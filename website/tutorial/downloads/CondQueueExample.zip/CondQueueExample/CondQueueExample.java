package desmoj.tutorial2.CondQueueExample;

import desmoj.core.simulator.*;
import desmoj.core.dist.*;
import desmoj.core.advancedModellingFeatures.CondQueue;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/**
 * This is the model class. It is the main class of a simple process-oriented
 * model of a container terminal using a condition queue to synchronise incoming
 * ships and trucks.
 * Trucks are assigned to a particular ship and wait at the harbour until that
 * ship arrives. Whenever a ship arrives at the port it notifies all waiting
 * trucks so that all trucks waiting for this ship can leave the queue and
 * proceed. The (un)loading of ships and trucks is not modelled.
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class CondQueueExample extends Model {

    /** A random number stream to determine the ship a truck is assigned to */
    private ContDistUniform shipTargetStream;

    /** A random number stream to determine the number of ship arrivals per day */
    private DiscreteDistUniform shipsPerDayStream;

    /** A random number stream to determine the time of arrival of the next ship */
    private ContDistUniform shipArrivalStream;

    /** A random number stream to determine the time of arrival of the next truck */
    private ContDistExponential truckArrivalStream;

    /** A CondQueue for trucks waiting on a particular ship */
    protected CondQueue<Truck> waitingTrucks;

    /** The condition for the trucks to check if their ship has arrived */
    protected ShipArrivedCondition shipArrived;

    /** A reference to the ship that's currently in the harbour */
    protected Ship currentShipInPort = null;

    /** A list to keep track of the awaited ships (so that trucks can be assigned to them) */
    protected ArrayList<Ship> incomingShips = new ArrayList<Ship>();

    /** A reference to the terminal office */
    protected TerminalOffice terminalOffice;

    /**
     * CondQueueExample constructor.
     *
     * Creates a new CondQueueExample model via calling
     * the constructor of the superclass.
     *
     * @param owner the model this model is part of (set to <tt>null</tt> when there is no such model)
     * @param modelName this model's name
     * @param showInReport flag to indicate if this model shall produce output to the report file
     * @param showInTrace flag to indicate if this model shall produce output to the trace file
     */
    public CondQueueExample(Model owner, String name, boolean showInReport, boolean showInTrace) {

        super(owner, name, showInReport, showInTrace);
    }
    /**
     * returns a description of the model to be used in the report.
     * @return model description as a string
     */
    public String description() {

        return "This is a simple model to demonstrate the use of the CondQueue construct."+
        "Every day between 1 and 6 ships arrive into a port."+
        "For each ship there are a certain number of trucks "+
        "waiting to deliver and receive containers."+
        "Every morning the container terminal office announces"+
        "how many new ships are going to arrive during the next 48 hours."+
        "From this time on trucks assigned to one of the incoming "+
        "ships start to arrive and wait in a condition queue. When a ship arrives at the harbour "+
        "it notifies the waiting trucks of its arrival so that all trucks"+
        "for this ship can leave the queue to the container interchange area and get"+
        "serviced. Afterwards the ship and the trucks terminate.";

    }
    /**
     * activates dynamic model components (simulation processes).
     *
     * This method is used to place all events or processes on the
     * internal event list of the simulator which are necessary to start
     * the simulation.
     *
     * In this case, the terminal office and the truck generator have to be
     * created and activated.
     */
    public void doInitialSchedules() {

        // create and activate the terminal office (= ship generator)
        terminalOffice = new TerminalOffice(this, "TerminalOffice", true);
        terminalOffice.activate(new TimeSpan(420, TimeUnit.MINUTES)); // at 07.00 o'clock of the first day

        // create and activate the truck generator right after the terminal office
        TruckGenerator truckGenerator = new TruckGenerator(this, "TruckGenerator", true);
        truckGenerator.activateAfter(terminalOffice);
    }
    /**
     * With the help of this method trucks determine for which
     * ship they are waiting.
     * @return the ship a truck is assigned to
     */
    protected Ship getAssignedShip() {

        // draw a sample from the ship target stream 
        // (sample is between 0 and 1, scale accordingly)
        int position = (int)(shipTargetStream.sample() * incomingShips.size());
        // return the ship at this position
        return incomingShips.get(position);
    }

    /** Returns the inter-arrival time of the next truck */
    protected double getTruckArrivalTime() {

        return truckArrivalStream.sample();
    }

    /** Returns the number of ships expected within the next 24 hours */
    protected long getNumOfShipArrivals() {

        return shipsPerDayStream.sample();
    }

    /** Returns the inter-arrival time of the next ship */
    protected double getShipArrivalTime() {

        return shipArrivalStream.sample();
    }

    /**
     * initialises static model components like distributions and queues.
     */
    public void init() {

        // initialise distributions
        // (1) to determine which ship will be assigned to a new truck
        shipTargetStream = new ContDistUniform(this,"Ship Target Stream",0.0,1.0, true ,false);
        // (2) for the number of ships to arrive during one day
        shipsPerDayStream = new DiscreteDistUniform(this, "Ships Per Day Stream", 1, 6, true, false);
        // (3) for the inter-arrival times of ships
        shipArrivalStream = new ContDistUniform(this, "Ship Arrival Stream", 0.0, 2880.0, true, false);
        // (4) for the inter-arrival times of trucks
        truckArrivalStream = new ContDistExponential(this, "Truck Arrival Stream", 45.0, true, false);

        // initialise condition queue
        waitingTrucks = new CondQueue<Truck>(this, "Waiting Trucks", true, true);
        // have queue check all entities when notified, not just the first one
        waitingTrucks.setCheckAll(true);

        // initialise condition the trucks are waiting on
        shipArrived = new ShipArrivedCondition(this, "Ship Arrived!", true);
    }

    /** run the model */  
    public static void main(String args[]) {

        // create model and experiment
        CondQueueExample model = new CondQueueExample(null, "CondQueueExample", true, false);
        Experiment exp = new Experiment("CondQueueExampleExperiment", TimeUnit.SECONDS, TimeUnit.MINUTES, null);

        // connect both
        model.connectToExperiment(exp);

        // set experiment parameters
        exp.setShowProgressBar(true);  // display a progress bar (or not)
        exp.stop(new TimeInstant(18000));   // set end of simulation at 1500 minutes
        exp.tracePeriod(new TimeInstant(0), new TimeInstant(8000));  // set the period of the trace
        exp.debugPeriod(new TimeInstant(0), new TimeInstant(2000));   // and debug output

        // start the Experiment with start time 0.0
        exp.start();

        // generate the report (and other output files)
        exp.report();
        // stop all threads still alive and close all output files
        exp.finish();
    }
}