package desmoj.tutorial2.CondQueueExample;

import desmoj.core.simulator.*;

/**
 * This class specifies the condition a truck is waiting on.
 * @author Olaf Neihardt, Ruth Meyer
 */
public class ShipArrivedCondition extends Condition<Truck> {

    /**
     * Constructs a new ShipArrivedCondition.
     * @param owner the model this condition belongs to
     * @param name this condition's name
     * @param showInTrace flag to indicate if this condition shall produce output for the trace
     */
    public ShipArrivedCondition(Model owner, String name, boolean showInTrace) {
        super(owner, name, showInTrace);
    }

    /** test routine that will be call from the condition queue to check whether
     *  the condition is met for the given entity (truck).
     */
    public boolean check(Truck t) {
        // is the current ship in port the ship this truck is waiting for?
        return ((CondQueueExample)getModel()).currentShipInPort == t.myShip;
    }
}