package desmoj.tutorial2.CondQueueExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a ship in the CondQueueExample
 * model.A ship arrives at the harbour and signals the waiting
 * truck that it's there. Since loading and unloading are
 * not modelled, the ship just leaves the system again.
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class Ship extends SimProcess {

    /**
     * Constructs a new ship.
     * @param owner the model this process belongs to
     * @param name this ship's name
     * @param showInTrace flag to indicate if this process shall produce output for the trace
     */
    public Ship(Model owner, String name, boolean showInTrace) {
        super(owner, name, showInTrace);
    }

    /**
     * Describes this ship's lifecycle:
     *
     * On arrival, the ship signals the waiting trucks that it is there now.
     * Then it directly leaves the system again since (un)loading is not
     * modelled.
     */
    public void lifeCycle() throws SuspendExecution {

        // get a reference to the model
        CondQueueExample model = (CondQueueExample)getModel();

        // arrive at the harbour
        model.incomingShips.remove(this);
        model.currentShipInPort = this;
        // send trace note just for information
        sendTraceNote("arrives at the port");

        // inform waiting trucks about arrival
        model.waitingTrucks.signal();

        // leave the system
        sendTraceNote("leaves the port");
    }
}
