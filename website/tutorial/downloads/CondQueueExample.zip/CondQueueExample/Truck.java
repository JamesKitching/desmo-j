package desmoj.tutorial2.CondQueueExample;

import desmoj.core.simulator.*;
import co.paralleluniverse.fibers.SuspendExecution;

/**
 * This class represents a truck in the CondQueueExample
 * model.A truck is assigned a ship to deliver a container to or retrieve
 * a container from, respectively. When it arrives at the terminal
 * it waits in a condition queue until the relevant ship arrives.
 * After that the truck just leaves the system since loading and unloading are
 * not modelled.
 * @author Olaf Neidhardt, Ruth Meyer
 */
public class Truck extends SimProcess {

    /** the ship this truck is assigned to */
    protected Ship myShip;

    /**
     * Constructs a new truck.
     * @param owner the model this process belongs to
     * @param name this ship's name
     * @param showInTrace flag to indicate if this process shall produce output for the trace
     */
    public Truck(Model owner, String name, boolean showInTrace) {
        super(owner, name, showInTrace);
        // get a ship assigned
        myShip = ((CondQueueExample)owner).getAssignedShip();
    }

    /**
     * Describes this truck's life cycle:
     *
     * On arrival, the truck enters the queue for waiting trucks to wait
     * until its assigned ship arrives at the terminal.
     * Then it directly leaves the system again since (un)loading is not
     * modelled.
     */
    public void lifeCycle() throws SuspendExecution {

        // get a reference to the model
        CondQueueExample model = (CondQueueExample)getModel();

        // arrive at the harbour
        // send additional information to trace
        sendTraceNote(" is assigned to " + myShip.getName());

        // enter CondQ for waiting
        model.waitingTrucks.waitUntil(model.shipArrived);

        // now the ship has arrived --> leave system
        sendTraceNote("Truck for "+ myShip.getName() +" was serviced and leaves");
    }
}
